print("SOMADOR")
print()

soma = 0
contador = 1

while True:
    valor = int(input(f"VALOR {contador}: "))
    contador = contador + 1

    if valor == 0:
        break
    soma = soma + valor

print(f"SOMA: {soma}")